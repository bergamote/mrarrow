
function showSubMenu(menu) {
	$(menu).show();
}
function hideSubMenu(menu) {
	$(menu).hide();
}
