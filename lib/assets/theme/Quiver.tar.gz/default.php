<!doctype html>
<head>
	<meta charset="UTF-8">
	<title><?= $page->title ?> | <?= $site['name'] ?></title>
	<link rel="stylesheet" href="<?= $page->style ?>">
	<script src="http://code.jquery.com/jquery-latest.min.js"></script>
	<script src="<?= $page->rel ?>script.js"></script>
</head>

<body>
<div id="page">

<header>
 <hgroup>
 <h3><?= $site['name'] ?></h3>
 <!--<h2><?= $site['tagline']?></h2>-->
 </hgroup>
</header>

<nav id="main">
<?= $page->menu_li ?>
</nav>

<article>

<?= $page->content ?>

</article>

<footer>
<?= (empty($site['email']))?'':"<div id=\"mail\">$site[email]</div>"; ?>
<div id="theme"><em>Mr Arrow with the <?= $site['theme'] ?> theme.</em></div>
</footer>

</div> <!-- /page -->

</body>
